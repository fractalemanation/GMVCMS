<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<h1>
		<?php if($value): ?>
			<?php if($key == 'phone'): ?>
				Номер телефона: <?php echo e($value); ?>

			<?php elseif($key == 'address'): ?>
				Адрес: <?php echo e($value); ?>

			<?php elseif($key == 'name'): ?>
				Имя: <?php echo e($value); ?>

			<?php elseif($key == 'type'): ?>
				Уборка: <?php echo e($value); ?>

			<?php elseif($key == 'room'): ?>
				Количество комнат: <?php echo e($value); ?>

			<?php elseif($key == 'bathroom'): ?>
				Количество санузлов: <?php echo e($value); ?>

			<?php elseif($key == 'window'): ?>
				Количество окон: <?php echo e($value); ?>

			<?php elseif($key == 'balcony'): ?>
				Количество балконов: <?php echo e($value); ?>

			<?php elseif($key == 'kitchen'): ?>
				Кухня
			<?php elseif($key == 'vacuum'): ?>
				Пылесос
			<?php elseif($key == 'side'): ?>
				Окна с двух сторон
			<?php elseif($key == 'sill'): ?>
				Подоконники
			<?php elseif($key == 'frame'): ?>
				Рамки
			<?php elseif($key == 'price'): ?>
				Цена: <?php echo e($value); ?>

			<?php endif; ?>
		<?php endif; ?>
	</h1>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>