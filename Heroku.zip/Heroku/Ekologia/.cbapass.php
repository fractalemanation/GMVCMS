<?php
$cba_juzek = 'ekologia';
$cba_baza = 'fractalamanation';
$cba_host = 'mysql.zzz.com.ua';
