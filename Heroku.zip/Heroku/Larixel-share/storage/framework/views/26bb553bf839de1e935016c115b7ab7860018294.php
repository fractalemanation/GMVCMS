<?php $__env->startSection('title', $category->title." - Laraxel"); ?>

<!--<?php $__env->startSection('title'); ?>
<?php echo e($category->title); ?> - TEST
<?php $__env->stopSection(); ?>-->
<?php $__env->startSection('content'); ?>
<div class="container">
	<?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<div class="row">
		<div class="col-sm-12">
			<h2><a href="<?php echo e(route('article', $article->slug)); ?>"><?php echo e($article->title); ?></a></h2>
			<p><?php echo $article->description_short; ?></p>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<h2 class="text-center">Пусто</h2>
	<?php endif; ?>
	<?php echo e($articles->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>