from django.contrib import admin
from .models import *

class SubscriberAdmin (admin.ModelAdmin):
	#list_display = ["name": "email"]#Значение для отдельного поля#fields = ["email"]#Отображает только email#exclude = ["email"]#Исключить показ поля email#list_filter = ["name"]#Фильтрация#search_fields = ["name"]#Фильтрация по указаным параметрам и ввод их
	list_display = [field.name for field in Subscriber._meta.fields]#Делаем значения для всех полей

	class Meta:
		model = Subscriber#Создаем значения полей к нашей таблице

admin.site.register(Subscriber, SubscriberAdmin)