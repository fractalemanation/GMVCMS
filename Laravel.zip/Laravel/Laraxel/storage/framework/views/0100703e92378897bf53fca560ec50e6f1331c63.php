<?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
<?php endif; ?>

<label for="">Имя</label>
<input type="text" class="form-control" name="name" placeholder="Имя" value="<?php if(old('name')): ?><?php echo e(old('name')); ?><?php else: ?><?php echo e(isset($user->name) ? $user->name : ""); ?><?php endif; ?>" required="required">
<label for="">Email</label>
<input type="email" class="form-control" name="email" placeholder="Email" value="<?php if(old('email')): ?><?php echo e(old('email')); ?><?php else: ?><?php echo e(isset($user->email) ? $user->email : ""); ?><?php endif; ?>" required="required">
<label for="">Пароль</label>
<input type="password" class="form-control" name="password" placeholder="Пароль">
<label for="">Подтвержедние пароля</label>
<input type="password" class="form-control" name="password_confirmation" placeholder="Подтвержедние пароля">
<hr>
<input class="btn btn-primary" type="submit" value="Сохранить">