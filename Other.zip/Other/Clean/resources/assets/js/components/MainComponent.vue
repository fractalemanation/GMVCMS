<template>
<div class="main-block container-fluid">
    <div id="myModal" class="modal fade" tabindex="-1">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button class="close" data-dismiss="modal">х</button>
            <h4 class="modal-title text-center">Оформление заказа</h4>
          </div>
          <div class="modal-body text-center">
            <form class="form-horizontal">
                <fieldset class="form-horizontal">
                  <div class="form-group">
                    <div class="col-sm-12">
                      <input type="text" v-model="phone" class="form-control" placeholder="Телефон">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-12">
                      <input type="text" v-model="address" class="form-control" placeholder="Адрес">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-12">
                      <input type="text" v-model="name" class="form-control" placeholder="Имя">
                    </div>
                  </div>
                  <div class="col-xs-12 col-md-12 bg-info">{{totalPrice}} ГРН</div>
                  <div class="form-group">
                    <div class="col-sm-12">
                      <button class="btn btn-default btn-md btn-block" type="submit" v-on:click.prevent="update">Заказать</button>
                    </div>
                  </div>
                </fieldset>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-12 logo-block">
        <div class="row">
            <div class="col-xs-10 col-md-10"><h1>UpClean</h1></div>
            <div class="col-xs-2 col-md-2 text-right"><h1 class="glyphicon glyphicon-leaf"></h1></div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="calculator-block col-md-4 text-center">
                <h1 class="title-calculator-main">УБОРКА</h1>
                <div class="row calculator-type-block">
                    <div class="col-xs-4 col-md-4" v-for="calculator in calculators">
                        <button class="btn btn-default btn-block text-uppercase" v-on:click="show = calculator.title; room = 0; bathroom = 0; window = 0; balcony = 0; kitchen = false; vacuum = false; side = false; sill = false; frame = false; totalPrice = 0; windowPrice = 0;">{{calculator.title}}</button>
                    </div>
                </div>
                <div v-for="calculator in calculators">
                    <div v-if="show === calculator.title">
                        <h1 class="title-calculator text-uppercase">{{calculator.title}}</h1>
                        <div class="col-xs-12 col-md-12 calculator-table">
                            <div v-for="field in calculator.fields">
                                <div class="row" v-if="field.type === 1">
                                    <div class="col-xs-2 col-md-2 minus" v-on:click="addMinus(field.price, field.title/*, field.id*/)">–</div>
                                    <!--<div class="col-xs-8 col-md-8 text-uppercase"><span v-bind:id="field.id" class="counter" attr="0">0</span> {{field.title}}</div>-->
                                    <div class="col-xs-8 col-md-8 text-uppercase"><span v-if="field.title == 'Комната'">{{room}}</span><span v-if="field.title == 'Санузел'">{{bathroom}}</span><span v-if="field.title == 'Окно'">{{window}}</span><span v-if="field.title == 'Балкон'">{{balcony}}</span> {{field.title}}</div>
                                    <div class="col-xs-2 col-md-2 plus" v-on:click="addPlus(field.price, field.title/*, field.id*/)">+</div>
                                </div>
                                <div class="row" v-else>
                                    <div class="col-xs-2 col-md-2"><input type="checkbox" v-on:click="addCheck(field.price, $event.target.checked, field.title)"></div>
                                    <div class="col-xs-8 col-md-8 text-uppercase">{{field.title}}</div>
                                    <div class="col-xs-2 col-md-2"><div class="glyphicon glyphicon-leaf"></div></div>
                                </div>
                            </div>
                            <div class="bg-info">{{totalPrice}} ГРН</div>
                            <button class="btn btn-default btn-block" data-toggle="modal" data-target="#myModal">Заказать</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>
</div>
</template>

<script>
    export default {
        props: ['calculators'],
        data () {
            return {
                show: 'Стандартная',
                totalPrice: 0,
                windowPrice: 0,
                phone: '',
                address: '',
                name: '',
                room: 0,
                bathroom: 0,
                window: 0,
                balcony: 0,
                kitchen: false,
                vacuum: false,
                side: false,
                sill: false,
                frame: false
            }
        },
        methods: {
            addMinus: function (price, type/*, index*/) {
                //let attr = document.getElementById(index).getAttribute('attr');
                if (this.totalPrice > 0 /*attr > 0*/) {
                    if (type == 'Окно' && this.window) {
                        if (this.side) {
                            this.windowPrice -= price;
                            this.totalPrice -= price * 2;
                        } else {
                            this.windowPrice -= price;
                            this.totalPrice -= price;
                        }
                        this.window--;
                    } else if (type == 'Комната' && this.room) {
                        this.totalPrice -= price;
                        this.room--;
                    } else if (type == 'Санузел' && this.bathroom) {
                        this.totalPrice -= price;
                        this.bathroom--;
                    } else if (type == 'Балкон' && this.balcony) {
                        this.totalPrice -= price;
                        this.balcony--;
                    }/*else {
                        this.totalPrice -= price;
                    }*/
                }
                /*if (index == document.getElementById(index).id) {
                    if (attr > 0) {
                        let attrPlus = parseInt(attr) - 1;
                        document.getElementById(index).setAttribute('attr', attrPlus);
                        document.getElementById(index).innerText = attrPlus;
                    }
                }*/
            },
            addPlus: function (price, type/*, index*/) {
                if (this.totalPrice >= 0) {
                    if (type == 'Окно') {
                        if (this.side) {
                            this.windowPrice += price;
                            this.totalPrice += price * 2;
                        } else {
                            this.windowPrice += price;
                            this.totalPrice += price;
                        }
                        this.window++;
                    } else if (type == 'Комната') {
                        this.totalPrice += price;
                        this.room++;
                    } else if (type == 'Санузел') {
                        this.totalPrice += price;
                        this.bathroom++;
                    } else if (type == 'Балкон') {
                        this.totalPrice += price;
                        this.balcony++;
                    } else {
                        this.totalPrice += price;
                    }
                }
                /*if (index == document.getElementById(index).id) {
                    let attr = document.getElementById(index).getAttribute('attr');
                    let attrPlus = parseInt(attr) + 1;
                    document.getElementById(index).setAttribute('attr', attrPlus);
                    document.getElementById(index).innerText = attrPlus;
                }*/
            },
            addCheck: function (price, status, type) {
                if (status) {
                    if (price == 2) {
                        this.totalPrice += this.windowPrice;
                        this.side = true;
                    }
                    else {
                        if (type == 'Кухня') {
                            this.totalPrice += price;
                            this.kitchen = true;
                        } else if (type == 'Пылесос') {
                            this.totalPrice += price;
                            this.vacuum = true;
                        } else if (type == 'Подоконники') {
                            this.totalPrice += price;
                            this.sill = true;
                        } else if (type == 'Рама') {
                            this.totalPrice += price;
                            this.frame = true;
                        } else {
                            this.totalPrice += price;
                        }
                    }
                } else {
                    if (price == 2) {
                        this.totalPrice -= this.windowPrice;
                        this.side = false;
                    }
                    else {
                        if (type == 'Кухня') {
                            this.totalPrice -=  price;
                            this.kitchen = false;
                        } else if (type == 'Пылесос') {
                            this.totalPrice -=  price;
                            this.vacuum = false;
                        } else if (type == 'Подоконники') {
                            this.totalPrice -=  price;
                            this.sill = false;
                        } else if (type == 'Рама') {
                            this.totalPrice -=  price;
                            this.frame = false;
                        } else {
                            this.totalPrice -= price;
                        }
                    }
                }
            },
            update: function () {
                if (this.phone) {
                    axios.post('/send', {phone: this.phone, address: this.address, name: this.name, type: this.show, room: this.room, bathroom: this.bathroom, window: this.window, balcony: this.balcony, kitchen: this.kitchen, vacuum: this.vacuum, side: this.side, sill: this.sill, frame: this.frame, price: this.totalPrice});
                    this.room = 0;
                    this.bathroom = 0;
                    this.window = 0;
                    this.balcony = 0;
                    this.kitchen = false;
                    this.vacuum = false;
                    this.side = false;
                    this.sill = false;
                    this.frame = false;
                    this.totalPrice = 0;
                    this.windowPrice = 0;
                    //$('.counter').text('0');
                    //$('.counter').attr('attr', '0');
                    $('#myModal').modal("hide");
                }
                else {
                    alert('Введите свой номер телефона, чтобы мы мог ли с вами связаться.');
                }
            }
        }
    }
</script>
