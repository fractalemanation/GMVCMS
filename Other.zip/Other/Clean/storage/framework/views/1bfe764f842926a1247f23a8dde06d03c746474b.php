<?php $__env->startSection('content'); ?>
<!--<div class="main-block container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="calculator-block col-md-4 text-center">
                <h1 class="title-calculator-main col-md-12">УБОРКА</h1>
                <?php $__currentLoopData = $сalculators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calculator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                <div>
	                    <button class="btn btn-default btn-calculator-type col-xs-12 col-md-4 text-uppercase" v-on:click="show = <?php echo e($calculator->id); ?>"><?php echo e($calculator->title); ?></button>
	                </div>
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	            <?php $__currentLoopData = $сalculators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calculator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                <div>
	                    <div v-if="show === <?php echo e($calculator->id); ?>">
	                        <h1 class="title-calculator col-md-12 text-uppercase"><?php echo e($calculator->title); ?></h1>
	                    </div>
	                </div>
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__currentLoopData = $сalculators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calculator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php echo e($calculator->title); ?>

  <?php if(isset($calculator->fields)): ?>
      <?php $__currentLoopData = $calculator->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($field->title); ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
<div id="congratulations" class="modal fade" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button class="close" data-dismiss="modal">х</button>
        <h4 class="modal-title text-center"><?php echo e($general[3]->description); ?></h4>
      </div>
      <div class="modal-body text-center">
        <h3><?php echo e($general[4]->description); ?></h3>
      </div>
      <div class="modal-footer">
        <button class="btn btn-default btn-block" data-dismiss="modal"><?php echo e($general[5]->description); ?></button>
      </div>
    </div>
  </div>
</div>
<main-component :calculators="<?php echo e($сalculators); ?>"></main-component>
<div class="container general-text">
  <h1 class="text-center"><?php echo e($general[0]->description); ?></h1>
	<p class="text-center"><?php echo e($general[1]->description); ?></p>
</div>
<div class="container-fluid container-fluid-background">
  <div class="container advantages text-center">
    <div>
      <div>
        <div class="glyphicon glyphicon-eye-open"></div>
        <h3><?php echo e($general[9]->description); ?></h3>
        <p><?php echo e($general[10]->description); ?></p>
      </div>
      <div>
        <div class="glyphicon glyphicon-usd"></div>
        <h3><?php echo e($general[11]->description); ?></h3>
        <p><?php echo e($general[12]->description); ?></p>
      </div>
      <div>
        <div class="glyphicon glyphicon-bitcoin"></div>
        <h3><?php echo e($general[13]->description); ?></h3>
        <p><?php echo e($general[14]->description); ?></p>
      </div>
      <div>
        <div class="glyphicon glyphicon-scale"></div>
        <h3><?php echo e($general[15]->description); ?></h3>
        <p><?php echo e($general[16]->description); ?></p>
      </div>
    </div>
  </div>
</div>
<div class="container service text-center">
    <h1><?php echo e($general[2]->description); ?></h1>
		<div class="row services">
      <?php echo $__env->make('layouts.services', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
        <li data-target="#myCarousel" data-slide-to="3"></li>
      </ol>
      <div class="carousel-inner">
        <div class="item active">
          <img src="<?php echo e(asset('images/room.jpg')); ?>" alt="Комната">
        </div>
        <div class="item">
          <img src="<?php echo e(asset('images/hall.jpg')); ?>" alt="Коридор">
        </div>
        <div class="item">
          <img src="<?php echo e(asset('images/kitchen.jpg')); ?>" alt="Кухня">
        </div>
        <div class="item">
          <img src="<?php echo e(asset('images/bathroom.jpg')); ?>" alt="Санузел">
        </div>
      </div>
      <a class="left carousel-control" href="#myCarousel" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
        <span class="sr-only">Назад</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
        <span class="sr-only">Вперед</span>
      </a>
    </div>
</div>
<div class="container-fluid container-fluid-background">
  <div class="container team text-center">
    <h1><?php echo e($general[17]->description); ?></h1>
    <p><?php echo e($general[18]->description); ?></p>
    <div class="row">
      <div class="col-md-4">
          <div>
            <h3 class="text-uppercase"><?php echo e($general[19]->description); ?></h3>
            <img src="<?php echo e(asset('images/cleaner-first.jpg')); ?>">
            <div><span class="glyphicon glyphicon-star-empty"></span> <?php echo e($general[20]->description); ?></div>
          </div>
      </div>
      <div class="col-md-4">
          <div>
            <h3 class="text-uppercase"><?php echo e($general[21]->description); ?></h3>
            <img src="<?php echo e(asset('images/cleaner-second.jpg')); ?>">
            <div><span class="glyphicon glyphicon-star-empty"></span> <?php echo e($general[22]->description); ?></div>
          </div>
      </div>
      <div class="col-md-4">
          <div>
            <h3 class="text-uppercase"><?php echo e($general[23]->description); ?></h3>
            <img src="<?php echo e(asset('images/cleaner-third.jpg')); ?>">
            <div><span class="glyphicon glyphicon-star-empty"></span> <?php echo e($general[24]->description); ?></div>
          </div>
      </div>
    </div>
  </div>
</div>
<div class="container questions text-center">
  <h1><?php echo e($general[25]->description); ?></h1>
  <div class="panel-group" id="collapse-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <a data-toggle="collapse" data-parent="#collapse-group" href="#el1" class="text-uppercase"><?php echo e($general[26]->description); ?></a>
      </div>
    <div id="el1" class="collapse in">
      <div class="panel-body"><?php echo e($general[27]->description); ?></div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <a data-toggle="collapse" data-parent="#collapse-group" href="#el2" class="text-uppercase"><?php echo e($general[28]->description); ?></a>
      </div>
      <div id="el2" class="collapse">
        <div class="panel-body"><?php echo e($general[29]->description); ?></div>
        </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <a data-toggle="collapse" data-parent="#collapse-group" href="#el3" class="text-uppercase"><?php echo e($general[30]->description); ?></a>
      </div>
      <div id="el3" class="collapse">
        <div class="panel-body"><?php echo e($general[31]->description); ?></div>
        </div>
    </div>
  </div>
</div>
<div class="container-fluid reviews-background text-center">
  <h1><?php echo e($general[6]->description); ?></h1>
  <div class="container">
    <div class="reviews">
      <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div>
            <div class="glyphicon glyphicon-user"></div>
            <h2><?php echo e($review->name); ?></h2>
            <p><?php echo e($review->message); ?></p>
          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<div class="container feedback">
  <h1 class="text-center"><?php echo e($general[7]->description); ?></h1>
  <form class="form-horizontal" action="/feedback" method="post">
    <?php echo e(csrf_field()); ?>

    <fieldset class="form-horizontal">
      <div class="form-group">
        <div class="col-sm-12">
          <input type="text" name="name" class="form-control" placeholder="Имя" required="required">
        </div>
      </div>
      <div class="form-group">
        <div class="col-sm-12">
          <textarea name="message" class="form-control" rows="10" placeholder="Отзыв" required="required"></textarea>
        </div>
      </div>
      <div class="form-group">
        <div class="col-sm-12">
          <button class="btn btn-default btn-md btn-block" type="submit"><?php echo e($general[8]->description); ?></button>
        </div>
      </div>
    </fieldset>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>