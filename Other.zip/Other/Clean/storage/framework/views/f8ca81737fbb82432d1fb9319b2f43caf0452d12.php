<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($service->children->count()): ?>
        <?php if($service->parent_id == 0): ?>
            <div class="col-md-4">
                <div class="panel panel-primary">
                    <div class="panel-heading"><h2><?php echo e($service->title ?? ''); ?></h2></div>
                    <div class="panel-body"><?php echo $__env->make('layouts.services', ['services' => $service->children, 'is_child' => true], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
                </div>
            </div>
        <?php else: ?>
            <h3><?php echo e($service->title ?? ''); ?></h3>
            <ul class="col-md-12">
                <?php echo $__env->make('layouts.services', ['services' => $service->children, 'is_child' => true], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </ul>
        <?php endif; ?>
    <?php else: ?>
        <?php if(isset($is_child)): ?>
            <li><?php echo e($service->title ?? ''); ?></li>
            <?php continue; ?>
        <?php endif; ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>