<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package betone
 */

?>

<footer id="colophon" class="site-footer"><a class="contact_phone_href_footer" href="tel: <?php echo get_theme_mod('contact_phone'); ?>"><?php echo get_theme_mod('contact_phone'); ?></a> <span>&#9742;</span> <a class="contact_phone_href_footer" href="tel: <?php echo get_theme_mod('contact_phone_second'); ?>"><?php echo get_theme_mod('contact_phone_second'); ?></a></footer>

<?php wp_footer(); ?>

<script type="text/javascript" src="//cdn.callbackhunter.com/cbh.js?hunter_code=c2a36ea347fd6639f24b0d9ff292fd55" charset="UTF-8"></script>

</body>
</html>
