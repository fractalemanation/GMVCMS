<?php
function coralina_customise_register($wp_customize) {
	$wp_customize->add_section('contact', array(
		'title' => __('Контакты', 'coralina'),
		'priority' => 30
	));

	$wp_customize->add_setting('contact_email', array(
		'default' => '',
		'transport' => 'refresh'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'contact_email', array(
		'label' => __('E-mail', 'coralina'),
		'section' => 'contact',
		'settings' => 'contact_email',
		'type' => 'text'
	)));
	$wp_customize->add_setting('contact_phone', array(
		'default' => '',
		'transport' => 'refresh'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'contact_phone', array(
		'label' => __('Номер телефона', 'coralina'),
		'section' => 'contact',
		'settings' => 'contact_phone',
		'type' => 'text'
	)));
	$wp_customize->add_setting('contact_address', array(
		'default' => '',
		'transport' => 'refresh'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'contact_address', array(
		'label' => __('Адрес', 'coralina'),
		'section' => 'contact',
		'settings' => 'contact_address',
		'type' => 'text'
	)));
}
add_action('customize_register', 'coralina_customise_register');