$(document).ready(function() {
	$('.order-click').click(function() {
		$('.feedback-fixed').slideToggle(250);
	});
	$('.order-close').click(function() {
		$('.feedback-fixed').slideUp(250);
	});
	$('.menu-button').click(function() {
		$('.menu-fixed').show(250);
		$('.menu-button').hide();
	});
	$('.menu-close').click(function() {
		$('.menu-fixed').hide(250);
		$('.menu-button').show();
	});
	$('.testimonies').click(function() {
		$('.block-license').slideToggle(250);
		$('.flexslider').flexslider({
			animation: "slide",
			controlNav: false
		});
	});
	$('.license-close').click(function() {
		$('.block-license').slideUp(250);
	});
	$('.supply').click(function() {
		$('.block-supply').slideToggle(250);
	});
	$('.supply-close').click(function() {
		$('.block-supply').slideUp(250);
	});
	let chosen = 0;
	let price = 0;
	$('.minus').click(function () {
		if ($('#amount'+this.id).val() >= 1) {
			$('#amount'+this.id).val(+$('#amount'+this.id).val() - 1);
			chosen--;
			let singlePrice = this.getAttribute('value');
			let cleanPrice = parseInt(singlePrice.replace(/\s/g, ''));
			price -= cleanPrice;
			$('.price-list-chosen-total').text(chosen);
			$('.price-list-amount-total').text(price);
		}
		if (chosen == 0 && price == 0) {
			setTimeout("$('.price-list-top').slideUp(250)", 500);
		}
	});
	$('.plus').click(function () {
		$('#amount'+this.id).val(+$('#amount'+this.id).val() + 1);
		chosen++;
		let singlePrice = this.getAttribute('value');
		let cleanPrice = parseInt(singlePrice.replace(/\s/g, ''));
		price += cleanPrice;
		$('.price-list-top').slideDown(250);
		$('.price-list-chosen-total').text(chosen);
		$('.price-list-amount-total').text(price);
	});

	/*let posterImg = document.querySelector('.slideImg'), poster = document.querySelector('.slide');
	let attr = posterImg.getAttribute('src');
	$('.slide').each(function(i,elem) {
		elem.setAttribute('style','background: url('+attr+'); width: 798px; height: 600px;');
	});*/
});