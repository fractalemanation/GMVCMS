<?php get_header(); ?>

<div class="wrapper">
	<main id="content" class="site-content-adult">
		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content-single', get_post_type() );
		endwhile;
		?>
	</main>
</div>
<?php get_footer();