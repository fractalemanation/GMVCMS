<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php the_title( sprintf( '<a href="%s"><h1>', esc_url( get_permalink() ) ), '</h1></a>' ); ?>
	<?php betone_post_thumbnail(); ?>
	<?php the_excerpt(); ?>
	<div class="article-reference"><?php echo sprintf( '<a href="%s">Подробнее', esc_url(get_permalink()) ), '</a>'; ?></div>
</article>
