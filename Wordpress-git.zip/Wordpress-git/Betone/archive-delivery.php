<?php get_header(); ?>

<div class="wrapper">
	<main id="main" class="site-content-adult">
		<div class="grid-item sidebar"><?php get_sidebar(); ?></div>
		<div class="grid-item article article-delivery">
			<?php
			echo get_breadcrumbs();
			?>
			<ul>
			<li><a href="<?php echo home_url("/delivery/"); ?>">Все</a></li>
			<?php
			$wcatTerms = get_terms('location', array('hide_empty' => 0, 'parent' => 0));
			foreach ($wcatTerms as $wcatTerm) :
			?>
				<li>
					<a href="<?php echo get_term_link($wcatTerm->slug, $wcatTerm->taxonomy); ?>"><?php echo $wcatTerm->name; ?></a>
				</li>
			<?php
			endforeach;
			?>
			</ul>
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content', get_post_type() );
			endwhile;
			the_posts_pagination();
			?>
		</div>
		<div class="grid-item license">
			<div class="grid-item testimonies">
				<img src="http://betonnyi-zavod.ru/template/img/svidetelstvo.svg">
				<p>Свидетельства и сертификаты качества</p>
			</div>
			<div class="grid-item supply">
				<img src="http://betonnyi-zavod.ru/template/img/dogovor.svg">
				<p>Договор поставки</p>
			</div>
			<div class="grid-item">
				<h1>Сеть бетонных заводов</h1>
				<h3>15 лет на рынке Москвы и МО</h3>
				<hr>
				<h2><?php echo get_theme_mod('contact_phone'); ?></h2>
				<button class="order-click">КОНСУЛЬТАЦИЯ С МЕНЕДЖЕРОМ</button>
			</div>
		</div>
	</main>
</div>

<?php get_footer();