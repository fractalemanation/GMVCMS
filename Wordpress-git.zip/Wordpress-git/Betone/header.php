<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package betone
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

	<header>

		<ul class="nav-top">
			<li><span>&#9930;</span><?php echo get_theme_mod('contact_email'); ?></li>
			<li><span>&#9742;</span><?php echo get_theme_mod('contact_phone'); ?></li>
			<li><button class="order-form order-click">ЗАКАЗАТЬ БЕТОН</button></li>
		</ul>

		<?php
		wp_nav_menu( array(
			'theme_location' => 'menu-1',
			'menu_id'        => 'primary-menu',
			'menu_class' => 'nav-menu',
			'container' => 'ul'
		) );
		?>

		<div class="feedback-fixed">
			<div class="order-close">X</div>
			<h1>Оставьте заявку</h1>
			<?php echo do_shortcode('[contact-form-7 id="44" title="Контактная форма 1"]'); ?>
		</div>

		<div class="menu-button"></div>
		<div class="menu-fixed">
			<div class="menu-close"></div>
			<div class="clear"></div>
			<?php
			wp_nav_menu( array(
				'theme_location' => 'menu-1',
				'menu_id'        => 'primary-menu',
				'menu_class' => 'nav-menu',
				'container' => 'ul'
			) );
			?>
		</div>

		<div class="block-license">
			<div class="license-close">X</div>
			<div class="flexslider">
			  <ul class="slides">
			  	<li>
			    	<div><img src="<?php echo get_template_directory_uri(); ?>/images/certificate.jpg" /></div>
			    <li>
			    	<div><img src="<?php echo get_template_directory_uri(); ?>/images/conformity.jpg" /></div>
			    </li>
			    <li>
			    	<div><img class="slideImg" src="<?php echo get_template_directory_uri(); ?>/images/chit.jpg" /></div>
			    </li>
			  </ul>
			</div>
		</div>

		<div class="price-list-top">
			<div class="price-list-chosen">Выбрано товаров: <span class="price-list-chosen-total">0</span></div>
			<div class="price-list-amount">Общая сумма: <span class="price-list-amount-total">0</span></div>
			<div class="price-list-order order-click">Расчитать общую скидку</div>
		</div>

	</header>