<?php get_header(); ?>

<?php filter_deals_post($_POST); ?>

<?php get_footer();