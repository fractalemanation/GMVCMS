<?php
/**
 * coralina functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package coralina
 */

if ( ! function_exists( 'coralina_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function coralina_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on coralina, use a find and replace
		 * to change 'coralina' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'coralina', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'coralina' ),
			'footer-support' => esc_html__( 'Footer Support', 'coralina' ),
			'footer-information' => esc_html__( 'Footer Information', 'coralina' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'coralina_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'coralina_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function coralina_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'coralina_content_width', 640 );
}
add_action( 'after_setup_theme', 'coralina_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function coralina_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'coralina' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'coralina' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'coralina_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function coralina_scripts() {
	wp_enqueue_style( 'coralina-style', get_stylesheet_uri() );
	wp_enqueue_style( 'coralina-component', get_template_directory_uri().'/layouts/component.css' );
	wp_enqueue_style( 'flexslider', get_template_directory_uri().'/layouts/flexslider.css' );//писать без префикса названия проекта общедоступные стили чтобы их увидели плагины
	wp_enqueue_style( 'prettyPhoto', get_template_directory_uri().'/layouts/prettyPhoto.css' );
	wp_enqueue_style( 'coralina-main', get_template_directory_uri().'/layouts/style.css' );

	wp_enqueue_script('jquery');
	wp_enqueue_script( 'flexslider', get_template_directory_uri() . '/js/libs/jquery.flexslider.js', array(), '', false );//false - загружать скрипты в шапке; array() - те скрипты которые нужно загрузить перед тем в котором они используются
	wp_enqueue_script( 'prettyPhoto', get_template_directory_uri() . '/js/libs/jquery.prettyPhoto.js', array(), '', false );
	wp_enqueue_script( 'responsiveTabs', get_template_directory_uri() . '/js/libs/jquery.responsiveTabs.js', array(), '', false );
	wp_enqueue_script( 'modernizr.custom', get_template_directory_uri() . '/js/libs/modernizr.custom.js', array(), '', false );
	//wp_enqueue_script( 'cbpBGSlideshow', get_template_directory_uri() . '/js/libs/cbpBGSlideshow.js', array(), '', false );
	wp_enqueue_script( 'jquery.imagesloaded', get_template_directory_uri() . '/js/libs/jquery.imagesloaded.min.js', array(), '', false );
	wp_enqueue_script( 'coralina-script', get_template_directory_uri() . '/js/script.js', array(), '', false );

	//wp_enqueue_script( 'coralina-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'coralina-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'coralina_scripts' );

function ale_add_scripts($hook) {
	if ($hook == 'post.php' || $hook == 'post-new.php' || $hook == 'page-new.php' || $hook = 'page.php') wp_enqueue_script('aletheme_metaboxes', get_template_directory_uri().'/inc/js/metaboxes.js', array('jquery', 'jquery-ui-core', 'jquery-ui-datepicker', 'media-upload', 'thickbox'));
}
add_action('add_enqueue_scripts', 'ale_add_scripts', 10);

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Post Type additions.
 */
require get_template_directory() . '/inc/post-type.php';

/**
 * Redux additions.
 */
require get_template_directory() . '/inc/sample-config.php';

/**
 * BreadCrumbs additions.
 */
require get_template_directory() . '/inc/breadcrumbs.php';

/**
 * MetaBoxes additions.
 */
require get_template_directory() . '/inc/metaboxes.php';

/**
 * Filter additions.
 */
require get_template_directory() . '/inc/filter.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}



function coralina_edit_admin_logo () {
?>
<style type="text/css">
body.login>div>h1>a {
	background: url("<?=get_template_directory_uri()?>/images/admin-logo.png")!important;
	width: 240px!important;
	height: 200px!important;
}
</style>
<?php }
add_action('login_enqueue_scripts', 'coralina_edit_admin_logo');

function coralina_edit_admin_logo_link() {
	return home_url('/');
}
add_filter('login_headerurl', 'coralina_edit_admin_logo_link');



function coralina_change_toolbar () {
	global $wp_admin_bar;
	$wp_admin_bar->add_menu(array(
		'id' => 'coralina-toolbar',
		'title' => 'Theme',
		'href' => admin_url('themes.php')
	));
	$wp_admin_bar->remove_node('wp-logo');
}
add_action('admin_bar_menu', 'coralina_change_toolbar', 40);

function coralina_add_remove_footer_link () {
	echo '<span id="footer-thankyou">Copyrights <a href="http://wordbean.zzz.com.ua">wordbean</a>.</span>';
}
add_filter('admin_footer_text', 'coralina_add_remove_footer_link');



function coralina_customise_register($wp_customize) {
	$wp_customize->add_section('ads', array(
		'title' => __('Реклама', 'coralina'),
		'priority' => 30
	));
	$wp_customize->add_setting('ads_code', array(
		'default' => '',
		'transport' => 'postMessage'//refresh
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'ads_code', array(
		'label' => __('Ваш рекламный код', 'coralina'),
		'section' => 'ads',
		'settings' => 'ads_code',
		'type' => 'textarea'
	)));

	$wp_customize->add_setting('ads_color', array(
		'default' => '#333333',
		'transport' => 'refresh'//postMessage
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'ads_color', array(
		'label' => __('Новый цвет', 'coralina'),
		'section' => 'ads',
		'settings' => 'ads_color'
	)));
}
function coralina_head () {
?>
<style type="text/css">
#ads_boxes {
	color: <?=get_theme_mod('ads_color')?>
}
</style>
<?php
}
add_action('wp_head', 'coralina_head');
add_action('customize_register', 'coralina_customise_register');
function coralina_customizer_live_preview () {
	wp_enqueue_script('coralina_customizes', get_template_directory_uri().'/js/customizer.js', array('jquery', 'customize-preview'), '', true);
}
add_action('customize_preview_init', 'coralina_customizer_live_preview');


if (function_exists('register_sidebar')) {
	register_sidebar(array(
		'name' => 'Pro WP Sidebar',
		'id' => 'prowp-sidebar',
		'description' => 'Вставьте сюда ваши виджеты',
		'before_widget' => '<div id="%1$s" class="widget coralina_widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2 class="widget_header">',
		'after_title' => '</h2>'
	));
}