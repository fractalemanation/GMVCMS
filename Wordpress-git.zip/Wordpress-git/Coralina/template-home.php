<?php
/**
 * Template name: Homepage
 */

get_header();
?>

<!-- HOT DEALS -->
 <section class="hotdeals">
	<div class="container">
	<div id="horizontalTab">
        <ul>
            <li><a href="#tab-1">Горячие предложения</a></li>
            <li><a href="#tab-2">Лучшие предложения</a></li>
            <li><a href="#tab-3">Самые последние</a></li>
            <li><a href="#tab-4">В тренде</a></li>

        </ul>

        <div id="tab-1">
            <div class="hot-d">
				<div class="hd-b">
					<?php
					$hot_deals = new WP_Query(array('post_type' => 'deals', 'posts_per_page' => '8', 'tax_query' => array('relation' => 'OR', array('taxonomy' => 'type', 'field'    => 'name', 'terms' => 'Горячие предложения'))));
					while ($hot_deals->have_posts()) :
						$hot_deals->the_post();
						$current_price = get_the_terms(get_the_id(), 'price');
						$current_location = get_the_terms(get_the_id(), 'location');
						$price = array_shift($current_price);
						$location = array_shift($current_location);

					?>
						<div class="hd-block">
							<img src="<?=get_the_post_thumbnail_url()?>" alt="" />
							<div class="hd-block-text">
								<?php the_title( sprintf( '<a href="%s"><h3>', esc_url( get_permalink() ) ), '</h3></a>' ); ?>
								<?php the_content(); ?>
								<div class="block-text-bottom">
									<span class="price"><?=substr($price->name, 0, -7)?></span>
									<span><img src="<?php echo get_template_directory_uri(); ?>/images/bus.png" alt="" /></span>
									<span class="date"><?=$location->name?></span>
								</div>
							</div>
						</div>

					<?php
					endwhile;
					?>
				</div>
			</div>
        </div>
        <div id="tab-2">
            <div class="hot-d">
				<div class="hd-b">
					<?php
					wp_reset_query();
					$hot_deals = new WP_Query(array('post_type' => 'deals', 'posts_per_page' => '6', 'tax_query' => array('relation' => 'OR', array('taxonomy' => 'type', 'field'    => 'name', 'terms' => 'Лучшие предложения'))));
					while ($hot_deals->have_posts()) :
						$hot_deals->the_post();
						$current_price = get_the_terms(get_the_id(), 'price');
						$current_location = get_the_terms(get_the_id(), 'location');
						$price = array_shift($current_price);
						$location = array_shift($current_location);
					?>
						<div class="hd-block">
							<img src="<?=get_the_post_thumbnail_url()?>" alt="" />
							<div class="hd-block-text">
								<?php the_title( sprintf( '<a href="%s"><h3>', esc_url( get_permalink() ) ), '</h3></a>' ); ?>
								<?php the_content(); ?>
								<div class="block-text-bottom">
									<span class="price"><?=substr($price->name, 0, -7);?></span>
									<span><img src="<?php echo get_template_directory_uri(); ?>/images/bus.png" alt="" /></span>
									<span class="date"><?=$location->name?></span>
								</div>
							</div>
						</div>

					<?php
					endwhile;
					?>
				</div>
			</div>
        </div>
        <div id="tab-3">
            <div class="hot-d">
				<div class="hd-b">
					<?php
					wp_reset_query();
					$hot_deals = new WP_Query(array('post_type' => 'deals', 'posts_per_page' => '6', 'tax_query' => array('relation' => 'OR', array('taxonomy' => 'type', 'field'    => 'name', 'terms' => 'Самые последние'))));
					while ($hot_deals->have_posts()) :
						$hot_deals->the_post();
						$current_price = get_the_terms(get_the_id(), 'price');
						$current_location = get_the_terms(get_the_id(), 'location');
						$price = array_shift($current_price);
						$location = array_shift($current_location);
					?>
						<div class="hd-block">
							<img src="<?=get_the_post_thumbnail_url()?>" alt="" />
							<div class="hd-block-text">
								<?php the_title( sprintf( '<a href="%s"><h3>', esc_url( get_permalink() ) ), '</h3></a>' ); ?>
								<?php the_content(); ?>
								<div class="block-text-bottom">
									<span class="price"><?=substr($price->name, 0, -7);?></span>
									<span><img src="<?php echo get_template_directory_uri(); ?>/images/bus.png" alt="" /></span>
									<span class="date"><?=$location->name?></span>
								</div>
							</div>
						</div>

					<?php
					endwhile;
					?>
				</div>
			</div>
        </div>
        <div id="tab-4">
            <div class="hot-d">
				<div class="hd-b">
					<?php
					wp_reset_query();
					$hot_deals = new WP_Query(array('post_type' => 'deals', 'posts_per_page' => '6', 'tax_query' => array('relation' => 'OR', array('taxonomy' => 'type', 'field'    => 'name', 'terms' => 'В тренде'))));
					while ($hot_deals->have_posts()) :
						$hot_deals->the_post();
						$current_price = get_the_terms(get_the_id(), 'price');
						$current_location = get_the_terms(get_the_id(), 'location');
						$price = array_shift($current_price);
						$location = array_shift($current_location);
					?>
						<div class="hd-block">
							<img src="<?=get_the_post_thumbnail_url()?>" alt="" />
							<div class="hd-block-text">
								<?php the_title( sprintf( '<a href="%s"><h3>', esc_url( get_permalink() ) ), '</h3></a>' ); ?>
								<?php the_content(); ?>
								<div class="block-text-bottom">
									<span class="price"><?=substr($price->name, 0, -7);?></span>
									<span><img src="<?php echo get_template_directory_uri(); ?>/images/bus.png" alt="" /></span>
									<span class="date"><?=$location->name?></span>
								</div>
							</div>
						</div>

					<?php
					endwhile;
					wp_reset_query();
					?>
				</div>
			</div>
        </div>

    </div>
	</div>

 </section>
 <section class="video">
	<div class="container">
		<div class="video-wrap">
		<a href="https://youtu.be/LkzUkcjNfzk" class="prettyphoto" title="video" ><img src="<?php echo get_template_directory_uri(); ?>/images/vidio-img.png" alt="" /></a>

		</div>
		<div class="vid-text">
			<h3><?php the_title(); ?></h3>
			<?php the_content(); ?>
		</div>
	</div>
 </section>
 <section class="gallery">
	<div class="gallery-wrap">
	<div class="flexgallery carousel">
		<ul class="slides">
			<?php
			wp_reset_query();
			$recent_gallery = new WP_Query(array('post_type' => 'gallery', 'posts_per_page' => 12)); 
			if ($recent_gallery->have_posts()) :
				while ($recent_gallery->have_posts()) :
					$recent_gallery->the_post();
			?>
			<li>
			  <div class="img-wrap"><img src="<?=get_the_post_thumbnail_url()?>" alt="" />
			  <a href="<?=get_the_post_thumbnail_url()?>" class="prettyphoto" ><div class="cover"><i class="fa fa-plus"></i> </div></a>
			  </div>
			  <div class="carousel-caption">
				<?php the_title( sprintf( '<p><a href="%s">', esc_url( get_permalink() ) ), '</a></p>' ); ?>
				<span><?php the_content(); ?></span>
			  </div>
			</li>
			<?php
			endwhile;
			endif;
			?>
		  </ul>
		</div>
	</div>
 </section>
 <section class="review">
	<div class="container">
		<div class="review-wrap">
		<h3>Отзывы</h3>
		<div class="flexreview">
		  <ul class="slides">
		  	<?php
			wp_reset_query();
			$recent_testimonials = new WP_Query(array('post_type' => 'testimonials', 'posts_per_page' => 3)); 
			if ($recent_testimonials->have_posts()) :
				while ($recent_testimonials->have_posts()) :
					$recent_testimonials->the_post();
			?>
				<li>
				<div class="review-item">
				<div class="rev-foto">
					<img src="<?=get_the_post_thumbnail_url()?>" alt="" />
				</div>
				<div class="rev-block">
					<div class="rev-head">
						<span class="name"><?=get_the_title()?></span>
						<span class="rating"><i class="fa fa-star"></i>93<em>/100</em></span>
						<span class="location"><i class="fa fa-map-marker"></i><?php echo get_the_date(); ?></span>
					</div>
					<div class="rev-block-text"><?php the_content(); ?></div>
				</div>
			</div>
			</li>
			<?php
			endwhile;
			endif;
			?>
		  </ul>
		</div>

		</div>
	</div>
 </section>
 <!-- OUR BLOG -->
 <section class="o-blog">
	<div class="container">
	<h3>Наш Блог</h3>
	<?php
	wp_reset_query();
	$recent_list = new WP_Query(array('post_type' => 'post', 'posts_per_page' => 3)); 
	if ($recent_list->have_posts()) :
		while ($recent_list->have_posts()) :
			$recent_list->the_post();
	?>
		<div class="blog-item">
			<a href="<?php the_permalink(); ?>" ><p><?php the_title() ?></p></a>
			<span><?php echo get_the_date(); ?></span><span><i class="fa fa-comment"></i><?=get_comments_number($recent_list->id)?></span>
		</div>
	<?php
	endwhile;
	endif;
	wp_reset_query();
	?>
		<div class="blog-item twitter">
			<div class="twit-l"><i class="fa fa-twitter"></i></div>
			<div class="tr"></div>
			<div class="twit-post">
			           Lorem Ipsum passages, and more recently with desktop publishing software
			                                                                           <span class="autor">@Corallina 1 day ago</span>
			</div>
		</div>
	</div>
 </section>
 <section class="bottom">
	<div class="container">
		<div class="bottom-nav">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'menu-1',
				'menu_id'        => 'primary-menu',
				'menu_class' => 'nav-menu',
				'container' => 'ul'
			) );
			?>
		</div>
		<div class="social">
			<?php
			if (!empty(get_post_meta($post->ID, 'ale_social_first', true))) :
			?>
				<a href="<?=get_post_meta($post->ID, 'ale_social_first', true)?>" target="_link" class="gp"><i class="fa fa-google-plus"></i></a>
			<?php
			endif;

			if (!empty(get_post_meta($post->ID, 'ale_social_second', true))) :
			?>
			<a href="<?=get_post_meta($post->ID, 'ale_social_second', true)?>" target="_link" class="tw"><i class="fa fa-twitter"></i></a>
			<?php
			endif;

			if (!empty(get_post_meta($post->ID, 'ale_social_third', true))) :
			?>
			<a href="<?=get_post_meta($post->ID, 'ale_social_third', true)?>" target="_link" class="fb"><i class="fa fa-facebook"></i></a>
			<?php
			endif;

			if (!empty(get_post_meta($post->ID, 'ale_social_fourth', true))) :
			?>
			<a href="<?=get_post_meta($post->ID, 'ale_social_fourth', true)?>" target="_link" class="ps"><i class="fa fa-pinterest"></i></a>
			<?php
			endif;
			?>
		</div>
	</div>
 </section>

<?php get_footer();