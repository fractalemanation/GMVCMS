<?php
$cba_juzek = 'betone';
$cba_baza = 'danyy385';
$cba_host = 'mysql.zzz.com.ua';
