<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'danyy385' );

/** MySQL database username */
define( 'DB_USER', 'betone' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Password0365' );

/** MySQL hostname */
define( 'DB_HOST', 'mysql.zzz.com.ua' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'w DU[nDPY+`~9<WM^)-pb*c=@cE|-|D3t=<}JitEy4;t1x5`a[3VTfSUYw_Q-3MK' );
define( 'SECURE_AUTH_KEY',  '<q#@05#vW!Fr7sx&Kfw5K_nP.J36]XHz7x+eOyeGsD;c=*[|dBczq6-^<}ww:wc]' );
define( 'LOGGED_IN_KEY',    '+?F4OC+Q,+Xes2aa5fPnov$vwqdd K#o8[IwD8QfC3;Fj%K|N1Wl[{vVIvSLK#Zo' );
define( 'NONCE_KEY',        'q>xR|KKP5;</dL3{ne2?B2d|j^*KFS((thRf;Suw+=f(S!y1N+EPN_)e`d,Xz4GS' );
define( 'AUTH_SALT',        '}X)yVFFa/E~k].O^//SO#bC=%0~!]@&b:AWyRV_N<dK/3eZL3K?U{,{1,yzDC/DB' );
define( 'SECURE_AUTH_SALT', '&NrdX*hY3g3S2pebn84&Ej9{_~502Iy,MV*GyWT~5|3;P51=-r{$WX[b-GitRQgR' );
define( 'LOGGED_IN_SALT',   '+$(i6!l|#L:?zgKr#H]a97h%:~8`c&{T:8~oj$J>LrIIf$U5RwVl4J#4wJ*0XG1z' );
define( 'NONCE_SALT',       'J,i<9LGZu@c/V9a&K xT]E{WN9py(wjs +@<2EODFW[JA&t7v(5zTGBeOMhg&`$R' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

define('FS_METHOD', 'direct');
$GLOBALS['_wp_filesystem_direct_method'] = 'relaxed_ownership';
define('DISABLE_WP_CRON', true);



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
