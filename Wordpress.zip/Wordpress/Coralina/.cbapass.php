<?php
$cba_juzek = 'coralina';
$cba_baza = 'frectalemanation';
$cba_host = 'mysql.zzz.com.ua';
