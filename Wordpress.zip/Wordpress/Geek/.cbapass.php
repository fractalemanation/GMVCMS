<?php
$cba_juzek = 'giki';
$cba_baza = 'gikaka';
$cba_host = 'mysql.zzz.com.ua';
